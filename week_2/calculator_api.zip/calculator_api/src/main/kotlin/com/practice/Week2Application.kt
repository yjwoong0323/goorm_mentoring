package com.practice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class Week2Application

fun main(args: Array<String>) {
	runApplication<Week2Application>(*args)
}
