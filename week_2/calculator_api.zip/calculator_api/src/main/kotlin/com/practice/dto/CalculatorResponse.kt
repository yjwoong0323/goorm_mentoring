package com.practice.dto

import java.math.BigDecimal

data class CalculatorResponse(
  val result: BigDecimal
)